/**
 * Project Wonderland
 *
 * Copyright (c) 2004-2009, Sun Microsystems, Inc., All Rights Reserved
 *
 * Redistributions in source code form must reproduce the above
 * copyright and this condition.
 *
 * The contents of this file are subject to the GNU General Public
 * License, Version 2 (the "License"); you may not use this file
 * except in compliance with the License. A copy of the License is
 * available at http://www.opensource.org/licenses/gpl-license.php.
 *
 * Sun designates this particular file as subject to the "Classpath" 
 * exception as provided by Sun in the License file that accompanied 
 * this code.
 */
package org.jdesktop.wonderland.modules.appbase.client;

/**
 * Shared Window State (SWS) Client.
 * <br><br>
 * A component that provides sharing of App Base window and view state between clients.
 * The window state that is shared includes: size.
 * The view state that is shared includes: offset, rotation.
 *
 * Also provides "shared operations" which are executed on the windows of all clients.
 * These include: close, restack.
 *
 * @author deronj, paulby
 */
@ExperimentalAPI
public class SwsClient {

    // TODO: needed?
    //protected final Throttle throttle = new Throttle(2, TimeUnit.SECONDS);

    protected static Logger logger = Logger.getLogger(SwsClient.class.getName());
    protected ArrayList<SwsClientListener> serverMoveListeners = null;

    // ********* TODO: connection
    
    /** Shared attributes. */
    public static final enum Attr { WINDOW_SIZE };

    /** Shared operations. */
    public static final enum Op { WINDOW_RESTACK, WINDOW_RESTACK };

    public enum Source { LOCAL, REMOTE };
    
    public SwsClient(ClientID clientID) {
        this.clientID = clientID;
        // ********* TODO: init connection
    }
    
    /**
     * Free resources.
     */
    public void cleanup () {
        // ********* TODO: close connection
    }
       
    /**
     * Allocate a unique SWS ID. This identifies an object to the SWS server. The object
     * may be an app, a window, or a view.
     */
    public void BigInteger allocateID () {
        allocates a local id;
        puts into localIDToGlobalID hash table local id -> NotYetAllocated
        
    }

    /**
     * Free a unique SWS ID.
     */
    public void BigInteger freeID () {
        // TODO
    }

======> DOESN'T WORK! CAN'T DO A WAIT IN A SWS OP!

    public void op (UUID swsID) {
        globalID = getGlobalID(swsID);
        if (globalID == Invalid) {
            logger.warning("Such and such op could not be shared, shared ID = " + swsID);
            return;
        }
        send the op message;
    }

    BigInteger getGlobalID (UUID localID) {
        while (true) {
            synchronized (localIDToGlobalID) {
                GlobalIDEntry entry = localIDToGlobalID.get(localID);
                if (entry == null) {
                    logger.warning("Sws global ID could not be allocated for local ID " + localID);
                    return Invalid;
                }
            }
            synchronized (entry) {
                if (entry.globalID == NotYetAllocated) {
                    try { entry.wait(entry); } catch (InterruptedException ex) {}
                }
            }
        }            
    }

    // Called on alloc success
    private void globalIDAllocated (UUID localID, BigInteger globalID) {
        synchronized (localIDToGlobalID) {
            GlobalIDEntry entry = localIDToGlobalID.get(localID);
            if (entry == null) {
                logger.warning("Internal error");
                return;
            }
        }
        synchronized (entry) {
            entry.globalID = globalID;
            entry.notify();
        }        
    }

    // Called on alloc failure and timeout
    private void globalIDNotAllocated (UUID localID) {
        synchronized (localIDToGlobalID) {
            localIDToGlobalID.remove(localID);
        }
    }

    // TODO: ops map local ID to global ID
    // If get fails, print warning msg: operation not shared
    // If global id is NotYetAllocated (0) then the operation waits

    //    If allocation comes back successful then set entry in map
    //        If entry is no longer in map the allocation timed out
    //    If allocation comes back failure or doesn't come back before timeout then remove it from the map and print a warning
    // If global ID is AllocationFailed then skip the shared op
    //    Remove map entry
    //    print warning msg: operation not shared
    // All pended operations are executed when an allocation comes back successful
    // A pended operation is removed when its own individual timeout expires
    // A pended operation
    // A pended operation which uses an id which is pending is piggybacked on the pending one
    //
    /*
                if (msgReceiver == null) {
                    msgReceiver = new ChannelComponent.ComponentMessageReceiver() {

                        public void messageReceived(CellMessage message) {
                            // Ignore messages from this client, TODO move this up into addMessageReciever with an option to turn off the test
                            BigInteger senderID = message.getSenderID();
                            if (senderID == null) {
                                senderID = BigInteger.ZERO;
                            }
                            if (!senderID.equals(cell.getCellCache().getSession().getID())) {
                                serverMoveRequest((MovableMessage) message);
                            }
                        }
                    };
                    channelComp.addMessageReceiver(getMessageClass(), msgReceiver);
    */


    /**
     * A request from this client to move the cell. The cell we be moved locally
     * and the requested change sent to the server. If the server denies the move
     * the cell will be moved to a server provided location and the listener
     * will be called. The server will
     * notify all other clients of the new location.
     * 
     * @param transform the requrested transformt
     * @param listener the listener that will be notified in the event the
     * system modifies this move (due to collision etc).
     */
    public void localMoveRequest(CellTransform transform, 
                                 CellMoveModifiedListener listener) {
    
        // make sure we are connected to the server
        if (channelComp == null || 
                channelComp.getStatus() != ClientConnection.Status.CONNECTED) {
            logger.warning("Cell channel not connected when moving cell " +
                           cell.getCellID());
            return;
        }

        // TODO throttle sends, we should only send so many times a second.
        final CellMessage req = createMoveRequestMessage(transform);
        final ResponseListener resp = createMoveResponseListener(listener);

        throttle.schedule(new Runnable() {
            public void run() {
                //System.out.println("Sending move at " + System.currentTimeMillis());
                channelComp.send(req, resp);
            }
        });

        applyLocalTransformChange(transform, TransformChangeListener.ChangeSource.LOCAL);
    }

    protected CellMessage createMoveRequestMessage(CellTransform transform) {
        return MovableMessage.newMoveRequestMessage(cell.getCellID(),
                                                    transform);
    }

    protected ResponseListener createMoveResponseListener(final CellMoveModifiedListener listener) {
        if (listener == null) {
            return new ResponseListener() {
                public void responseReceived(ResponseMessage response) {
                    if (response instanceof ErrorMessage) {
                        ErrorMessage error = (ErrorMessage) response;
                        logger.log(Level.WARNING, "Error sending move: " +
                                   error.getErrorMessage(),
                                   error.getErrorCause());
                    }
                }
            };
        }

        return new ResponseListener() {
            public void responseReceived(ResponseMessage response) {
                CellTransform requestedTransform = null;
                CellTransform actualTransform = null;

                if (response instanceof MovableMessageResponse) {
                    MovableMessageResponse msg = (MovableMessageResponse) response;
                    actualTransform = new CellTransform(msg.getRotation(),
                                                        msg.getTranslation(),
                                                        msg.getScale());
                }
               
                int reason = 1;
                listener.moveModified(requestedTransform, reason, actualTransform);
                // TODO Trigger a cell move with the SERVER_ADJUST source
             }
        };
    }

    /**
     * Apply the transform change to the cell
     * @param transform
     * @param source
     */
    protected void applyLocalTransformChange(CellTransform transform, ChangeSource source) {
        cell.setLocalTransform(transform, source);
    }
    
    /**
     * A request from this client to move the cell. The cell we be moved locally
     * and the requested change sent to the server. If the server denies the move
     * the cell will be moved to a server provided location. The server will
     * notify all other clients of the new location.
     * 
     * @param transform
     */
    public void localMoveRequest(CellTransform transform) {
        localMoveRequest(transform, null);
    }
    
    /**
     * Called when a message arrives from the server requesting that the
     * cell be moved.
     * @param msg the message received from the server
     */
    protected void serverMoveRequest(MovableMessage msg) {
        CellTransform transform = msg.getCellTransform();
        applyLocalTransformChange(transform, TransformChangeListener.ChangeSource.REMOTE);
        notifyServerCellMoveListeners(msg, transform, CellMoveSource.REMOTE);
    }
    
    
    
    /**
     * Listen for move events from the server
     * @param listener
     */
    public void addServerCellMoveListener(CellMoveListener listener) {
        if (serverMoveListeners==null) {
            serverMoveListeners = new ArrayList();
        }
        serverMoveListeners.add(listener);
    }
    
    /**
     * Remove the server move listener.
     * @param listener
     */
    public void removeServerCellMoveListener(CellMoveListener listener) {
        if (serverMoveListeners!=null) {
            serverMoveListeners.remove(listener);
        }
    }
    
    /**
     * Notify any serverMoveListeners that the cell has moved
     * 
     * @param transform
     */
    protected void notifyServerCellMoveListeners(MovableMessage msg, CellTransform transform, CellMoveSource source) {
        if (serverMoveListeners==null)
            return;

        for(CellMoveListener listener : serverMoveListeners) {
            listener.cellMoved(transform, source);
        }
    }
    
    @ExperimentalAPI
    public interface CellMoveListener {
        /**
         * Notification that the cell has moved. Source indicates the source of 
         * the move, local is from this client, remote is from the server.
         * 
         * @param transform
         * @param source
         */
        public void cellMoved(CellTransform transform, CellMoveSource source);
    }
    
    @ExperimentalAPI
    public interface CellMoveModifiedListener {
        /**
         * Notification from the server that the requested move was
         * not possible and a modified move took place instead. The cell should be positioned with the actualTransform
         * transform.
         * 
         * @param requestedTransform
         * @param reason
         * @param actualTransform
         */
        public void moveModified(CellTransform requestedTransform, int reason, CellTransform actualTransform);
    }
}
