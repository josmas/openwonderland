Extracted from : jogl-1.1.0-rc4-macosx-universal.zip
On date        : Fri Apr 13 18:02:38 PDT 2007
