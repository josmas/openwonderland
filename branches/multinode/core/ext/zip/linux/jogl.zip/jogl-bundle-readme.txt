Extracted from : jogl-1.1.0-rc4-linux-i586.zip
On date        : Fri Apr 13 18:02:37 PDT 2007
