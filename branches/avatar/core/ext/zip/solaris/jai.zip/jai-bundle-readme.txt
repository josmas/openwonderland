Extracted from : jai-1_1_4-pre-dr-b03-lib-solaris-i586-20_Apr_2007.zip
On date        : Fri Apr 20 12:40:58 PDT 2007
