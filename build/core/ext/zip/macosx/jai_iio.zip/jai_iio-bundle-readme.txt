Extracted from : jai-imageio-1_2-pre-dr-b04-lib-linux-i586-20_Apr_2007.zip
On date        : Fri Apr 20 12:45:31 PDT 2007
