Extracted from : jmf-2_1_1e-windows-i586.exe
On date        : Tue Mar 20 21:53:00 PDT 2007
