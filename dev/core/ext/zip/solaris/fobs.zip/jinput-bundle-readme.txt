Extracted from : jinput_combined_dist_20061029.zip
On date        : Tue Mar 20 18:04:17 PDT 2007
