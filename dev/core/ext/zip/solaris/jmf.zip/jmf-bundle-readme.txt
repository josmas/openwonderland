Extracted from : jmf-2_1_1e-alljava.zip
On date        : Tue Mar 20 21:53:00 PDT 2007
