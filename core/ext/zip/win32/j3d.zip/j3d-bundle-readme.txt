Extracted from : java3d-1_5_2-pre1-0711150204-windows-i586.zip
On date        : Thu Nov 15 09:25:50 PST 2007
