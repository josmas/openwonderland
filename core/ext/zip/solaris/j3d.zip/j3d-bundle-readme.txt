Extracted from : java3d-1_5_2-pre1-0711150201-solaris-x86.zip
On date        : Thu Nov 15 09:25:52 PST 2007
