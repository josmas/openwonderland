Extracted from : joal-1.1.1-pre-20070413-linux-i586.zip
On date        : Fri Apr 13 18:02:46 PDT 2007
