Extracted from : jinput_combined_dist_20061029.zip
On date        : Fri Apr 13 18:03:35 PDT 2007
